<?php
	if(isset($_POST['delete'])){
		$id=mysqli_real_escape_string($con,$_POST['id']);
		$query1=mysqli_query($con,"DELETE FROM `charges` WHERE  id=$id") or die(mysqli_error($con));
		$rowscount=mysqli_affected_rows($con);
		if($rowscount>0){
			echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">X</button><strong>Well done!</strong> you have delete a charge successfully</div>';
		}
		else{
			echo '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">X</button><strong>Unsuccessful!</strong> You have not delete a charge successfully.</div>';
		}
	}
?>
<div class="panel panel-default">
	<div class="panel-heading">Charges List
		<!-- <a href="addcities.php" class="btn btn-info pull-right" style="margin-top:-7px;" ><i class="fa fa-plus"></i>Add New City</a> -->
	</div>
		<div class="panel-body" id="same_form_layout" style="padding: 11px;">
			<div id="basic-datatable_wrapper" class="dataTables_wrapper form-horizontal dt-bootstrap no-footer">
				<div class="row">
					<div class="col-sm-12 table-responsive">
						<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered dataTable no-footer" id="basic-datatable" role="grid" aria-describedby="basic-datatable_info"> 
							<thead>
								<tr role="row">
								   <th style="width: 44%;" class="sorting_asc" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending" style="width: 179px;">Charges Name</th>
								   <th style="width: 44%;" class="sorting_asc" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending" style="width: 179px;">Charges Value</th>
								   <th style="width: 44%;" class="sorting_asc" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending" style="width: 179px;">Type</th>
								  <th class="sorting" tabindex="0" aria-controls="basic-datatable" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 108px;">Action</th>
								</tr>
							</thead>
							<tbody>
							<?php
								
							
								$query1=mysqli_query($con,"Select * from charges order by id desc");
								while($fetch1=mysqli_fetch_array($query1)){
							?>
								<tr class="gradeA odd" role="row">
									<td class="sorting_1"><?php echo $fetch1['charge_name']; ?></td>
									<td class="sorting_1"><?php echo $fetch1['charge_value']; ?></td>
									<td class="sorting_1"><?php if($fetch1['charge_type']==1){echo 'Fixed Amount'; }  else{echo 'Percentage'; } ; ?></td>
									<td class="center inline_Btn">
										<!-- <a href="editcharges.php" name="id" value="<?php echo $fetch1['id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>

										<a href="#" name="delete" value="<?php echo $fetch1['id']; ?>" onclick="return confirm('Are are sure you want to delete this charge?')"><span class="glyphicon glyphicon-trash"></span></a> -->
										<form action="editcharges.php" method="post" style="display: inline-block;">
											<input type="hidden" name="id" value="<?php echo $fetch1['id']; ?>">
											<button type="submit" name="edit"  >
											  <span class="glyphicon glyphicon-edit"></span> 
											</button>
											</form>
											<form action="" method="post" style="display: inline-block;">
											<input type="hidden" name="id" value="<?php echo $fetch1['id']; ?>">
											<button type="submit" name="delete" onclick="return confirm('Are are sure you want to delete this charge?')" >
											  <span class="glyphicon glyphicon-trash"></span> 
											</button>
										</form>
									
									</td>
								</tr>
								<?php
									
								}
								
								?>
							</tbody>
						</table>
			
				</div>
			</div>
		</div>
	</div>
</div>